#!/bin/bash

if [[ ! `ping 8.8.8.8 -c 1 | grep "1 received"` ]]; then
echo "No internet"
exit 1
fi

if [[ ! `service auditd status` ]]; then
  if [[ `apt` ]]; then
    sudo apt update
    sudo apt -y install auditd audispd-plugins
  elif [[ `yum` ]]; then
    sudo yum makecache
    sudo yum -y install audit audit-libs audispd-plugins
  fi

  sudo chmod 777 /etc/audit/auditd.conf
  sed -i -r "s/= RAW/= ENRICHED/g" /etc/audit/auditd.conf
  sed -i -r "s/name_format = NONE/name_format = NUMERIC/g" /etc/audit/auditd.conf
  sed -i -r "s/disp_qos = lossy/disp_qos = lossless/g" /etc/audit/auditd.conf
  sudo chmod 640 /etc/audit/auditd.conf

  if [[ -d /etc/audit/plugins.d/ ]]; then
  sudo chmod 777 /etc/audit/plugins.d/syslog.conf
  sed -i -r "s/active = no/active = yes/g" /etc/audit/plugins.d/syslog.conf
  sudo chmod 640 /etc/audit/plugins.d/syslog.conf
  fi

  if [[ -d /etc/audisp/plugins.d/ ]]; then
  sudo chmod 777 /etc/audisp/plugins.d/syslog.conf
  sed -i -r "s/active = no/active = yes/g" /etc/audisp/plugins.d/syslog.conf
  sudo chmod 640 /etc/audisp/plugins.d/syslog.conf
  fi
fi
  sudo wget -q https://raw.githubusercontent.com/Neo23x0/auditd/master/audit.rules -O /etc/audit/rules.d/sec.rules
  
  sudo touch /tmp/sv.rules
  sudo chmod 777 /tmp/sv.rules
  sudo cat > /tmp/sv.rules <<EOF

# ignore errors
-i
# delete all rules
-D
# for busy systems
-b 8192
# capabilities, xattr, time change
-a always,exit -F arch=b32 -S capset -k key_api_caps
-a always,exit -F arch=b64 -S capset -k key_api_caps
-a always,exit -F arch=b32 -S setxattr,lsetxattr,fsetxattr -k key_api_xattr
-a always,exit -F arch=b64 -S setxattr,lsetxattr,fsetxattr -k key_api_xattr
-a always,exit -F arch=b32 -S settimeofday,adjtimex,clock_settime -k key_api_time
-a always,exit -F arch=b64 -S adjtimex,settimeofday,clock_settime -k key_api_time

# file monitoring
-a always,exit -S all -F path=/etc/shadow -F perm=r -F auid!=-1 -k key_etc_read
-a always,exit -S all -F path=/etc/sudoers -F perm=r -F auid!=-1 -k key_etc_read
-a always,exit -S all -F dir=/etc/sudoers.d -F perm=r -F auid!=-1 -k key_etc_read
-a always,exit -S all -F path=/etc/passwd -F perm=r -F auid!=-1 -k key_etc_read
-a always,exit -S all -F path=/etc/group -F perm=r -F auid!=-1 -k key_etc_read
-a always,exit -S all -F path=/etc/security/opasswd -F perm=r -F auid!=-1 -k key_etc_read
-a always,exit -S all -F dir=/var/log -F perm=rwa -F auid!=-1 -k key_var_log_access
-w /etc -p wa -k key_etc_modify
-w /home -p rwa -k key_home_access
-w /root -p rwa -k key_home_access
-w /var/www -p rwa -k key_home_access
-w /var/spool/cron -p wa -k key_cron_modify
-w /var/spool/at -p wa -k key_cron_modify
-w /bin -p wa -k key_bin_modify
-w /usr/bin -p wa -k key_bin_modify
-w /sbin -p wa -k key_bin_modify
-w /usr/sbin -p wa -k key_bin_modify
-w /usr/local/bin -p wa -k key_bin_modify
-w /usr/local/sbin -p wa -k key_bin_modify
-w /usr/libexec -p wa -k key_bin_modify
-w /lib -p wa -k key_lib_modify
-w /lib64 -p wa -k key_lib_modify
-w /usr/lib -p wa -k key_lib_modify
-w /usr/lib64 -p wa -k key_lib_modify
-w /boot -p wa -k key_boot_modify
-w /var/www -p wa -k key_www_modify

# exclude bins
-a never,exit -F exe=/usr/bin/vmtoolsd
-a never,exit -F exe=/usr/sbin/haproxy
-a never,exit -F exe=/usr/sbin/cron
-a never,exit -F exe=/lib/systemd/systemd-timesyncd
-a never,exit -F exe=/lib/systemd/systemd-logind

# network activities
-a always,exit -F arch=b32 -S socket -F a0=0x2 -k key_api_socket
-a always,exit -F arch=b64 -S socket -F a0=0x2 -k key_api_socket
-a always,exit -F arch=b32 -S socket -F a0=0xA -k key_api_socket
-a always,exit -F arch=b64 -S socket -F a0=0xA -k key_api_socket
-a always,exit -F arch=b32 -S socket -F a0=0x11 -k key_api_socket
-a always,exit -F arch=b64 -S socket -F a0=0x11 -k key_api_socket
-a always,exit -F arch=b32 -S connect -F a2=0x10 -k key_api_connect
-a always,exit -F arch=b64 -S connect -F a2=0x10 -k key_api_connect
-a always,exit -F arch=b32 -S connect -F a2=0x1C -k key_api_connect
-a always,exit -F arch=b64 -S connect -F a2=0x1C -k key_api_connect
-a always,exit -F arch=b32 -S accept4 -k key_api_accept
-a always,exit -F arch=b64 -S accept4 -k key_api_accept
-a always,exit -F arch=b64 -S accept -k key_api_accept
-a always,exit -F arch=b32 -S listen -k key_api_listen
-a always,exit -F arch=b64 -S listen -k key_api_listen

# execute
-a always,exit -F arch=b32 -S execve -F euid>0 -F euid<<UID_MIN> -F key=key_execve_daemon
-a always,exit -F arch=b32 -S execveat -F euid>0 -F euid<<UID_MIN> -F key=key_execve_daemon
-a always,exit -F arch=b64 -S execve -F euid>0 -F euid<<UID_MIN> -F key=key_execve_daemon
-a always,exit -F arch=b64 -S execveat -F euid>0 -F euid<<UID_MIN> -F key=key_execve_daemon
-a always,exit -F arch=b32 -S execve -k key_execve
-a always,exit -F arch=b32 -S execveat -k key_execve
-a always,exit -F arch=b64 -S execve -k key_execve
-a always,exit -F arch=b64 -S execveat -k key_execve

# kernel modules, process trace, special permissions
-a always,exit -F arch=b32 -S init_module,delete_module -F auid!=-1 -k key_api_kernel_mods
-a always,exit -F arch=b32 -S finit_module -F auid!=-1 -k key_api_kernel_mods
-a always,exit -F arch=b64 -S init_module,delete_module -F auid!=-1 -k key_api_kernel_mods
-a always,exit -F arch=b64 -S finit_module -F auid!=-1 -k key_api_kernel_mods
-a always,exit -F arch=b32 -S ptrace -k key_api_ptrace
-a always,exit -F arch=b64 -S ptrace -k key_api_ptrace
-a always,exit -F arch=b32 -S setuid,setgid,setreuid,setregid -k key_api_setuid
-a always,exit -F arch=b64 -S setuid,setgid,setreuid,setregid -k key_api_setuid
EOF

sudo cp /tmp/sv.rules /etc/audit/rules.d/sv.rules
sudo service auditd restart

exit 0
