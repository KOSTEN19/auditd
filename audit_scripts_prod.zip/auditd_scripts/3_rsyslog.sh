#!/bin/bash
sudo touch /etc/rsyslog.d/audit.conf

sudo chown root:root /etc/rsyslog.d/audit.conf
sudo echo "local7.notice /var/log/cmd.log" > /etc/rsyslog.d/audit.conf
sudo echo "auth,authpriv.*,daemon.*,cron.*,local7.notice @﻿IP:﻿PORT" >> /etc/rsyslog.d/audit.conf
sudo echo "log_file = /var/log/audit/audit.log" >> /etc/audit/auditd.conf
sudo echo -e  "
\$ModLoad imfile \n\$InputFileName /var/log/audit/audit.log \n\$InputFileTag tag_audit \n\$InputFileStateFile audit_log \n\$InputFileSeverity info \n\$InputFileFacility local7 \n\$InputRunFileMonitor\n\$InputFilePollInterval 0\n*.* @172.18.0.12:514 \nsudo service rsyslog restart" > /etc/rsyslog.conf 
