#!/bin/bash
sudo touch /etc/rsyslog.d/audit.conf

sudo chown root:root /etc/rsyslog.d/audit.conf
sudo echo "local7.notice /var/log/cmd.log" > /etc/rsyslog.d/audit.conf
sudo echo "auth,authpriv.*,daemon.*,cron.*,local7.notice @﻿IP:﻿PORT" >> /etc/rsyslog.d/audit.conf

sudo service rsyslog restart
