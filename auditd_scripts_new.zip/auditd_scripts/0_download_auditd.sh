#!/bin/bash

if [[ `apt-get` ]]; then
    sudo apt-get update
    sudo apt-get install  audit
fi

exit 0
